function convertLength() {
    let input = document.getElementById("inputID").value;
    let sourceUnit = document.getElementById("sourceUnitID").value;
    let targetUnit = document.getElementById("targetUnitID").value;
    let result = 0;
    let output;


}